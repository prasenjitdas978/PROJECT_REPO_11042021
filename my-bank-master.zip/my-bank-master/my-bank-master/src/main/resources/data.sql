INSERT INTO accounts (id, name, balance) VALUES (1, 'John Smith', 100.0);
INSERT INTO accounts (id, name, balance) VALUES (2, 'Tony Stark', 100.0);